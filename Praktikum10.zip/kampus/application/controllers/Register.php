<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

    public function index(){
        $data = [];
        $this->load->view('register',$data);
    }

    public function save(){
        //panggil model
        $this->load->model("user_model","user");

        $_username = $this->input->post('username');
        $_email = $this->input->post('email');
        $_password = $this->input->post('password');
        $_confirm_password = $this->input->post('confirm_password');
        $_role = $this->input->post('role');
        $idedit = $this->input->post('idedit'); //hidden field, ada kalo update

        //buat array 
        $data_user[] = $_username; // 1
        $data_user[] = $_password; // 2
        $data_user[] = $_email; // 3
        $data_user[] = $_role; // 4
        //dimasukin ke $data_user dibawah 

        if(isset($idedit)){
            //update data lama
            $data_user[] = $idedit; // 8
            $this->user->update($data_user); //data harus berupa array
        }else{
            //save data baru
            // panggil fungsi register yg ada di model
            $this->user->register($data_user); //data harus berupa array
        }

        //redirect itu mengembalikan halaman
        redirect(base_url().'index.php/login');
        //base url dari config = localhost/webku/   
    }
}